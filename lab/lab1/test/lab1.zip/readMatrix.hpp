#include <iostream>
//#include <stdlib>

void readMatrix(int array[][3],int choice);
