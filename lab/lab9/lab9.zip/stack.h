#ifndef STACK
#define STACK
#include <iostream>
#include <string>
#include <stack>
#include <queue>
#include <cstdlib>
#include <ctime>

class Stack{

public:
static std::string get_palindrome(std::string str);

};
#endif