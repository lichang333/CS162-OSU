#ifndef QUEUE
#define QUEUE
#include <iostream>
#include <string>
#include <stack>
#include <queue>
#include <cstdlib>
#include <ctime>

class Queue{
public:

int getNum(double prob);
void printQueue(std::queue<int> q);
void queue_function();

};
#endif