In this lab, I created 3 recursive functions:

- Reverse a string 
- Calculate the sum of the array
- Calculate the triangular number

By running the program, the user can input '1', '2', '3' or 'q' to going to thees three recursive function or type 'q' to quit the program.

Here is some brief manual to illustrate how to operate each funciton:

(1) Reverse a string : When the "input" appeard, type any string and hit enter. Then, you will get a reversed string that you entered.

(2) Calculate the sum of the array: in this function, you need to type 5 integer number and use space to seperate them. (eg: 1 2 3 4 5) Then, the fuction will calulate the sum of this 5 element array.

(3) Calculate the triangular number: In this function, you can type a integer number and the system will calulate the Nth sum of the triangular number. For example, when you type 3, you will get output result: 6 (1+2+3=6)

(q) Quit: you can type 'q' on the menu to quiz this program.


