#include "state_facts.h"

int main(int argc, char *argv[]) {

  int states = atoi(argv[2]);

  ;

  if (argc != 5) {
    cout << "\nWrong input.\nHint:\ntype -s for state;\ntype -f for target "
            "filename;\nEach of number should be greater than "
            "0.\nexample:a.out -s 2 -f states1.txt\n"
         << endl;

    return 1;
  }

  do {
    states = atoi(argv[2]);
    struct state *state_fact;
    int text_count = 0;
    state_fact = new state[states];

    if (argv[1][0] == '-' && argv[1][1] == 's' && argv[3][0] == '-' &&
        argv[3][1] == 'f') {
      fstream tar_file;
      string get_file;
      int NUM_STATES = atoi(argv[2]);

      tar_file.open(argv[4]);
      if (!tar_file) {
        cout << "I cannot find the file.\n";
        return 1;
      }
      string text[255];

      while (!tar_file.eof()) {
        getline(tar_file, get_file);
        text[text_count] = get_file;
        text_count++;
      }
      int state_count = 0;
      int county_count = 0;
      int number = 0;
      for (int i = 0; i < text_count; i++) {
        string temp_arr[12];
        int last_space = 0;
        int word_count = 0;
        for (int j = 0; j < text[i].size(); j++) {
          if (text[i][j] == ' ') {
            temp_arr[word_count] = text[i].substr(last_space, j - last_space);
            word_count++; // scan
            last_space = j + 1;
          }
        }
        temp_arr[word_count] = text[i].substr(last_space, last_space);
        word_count++;

        if (word_count == 3 && !(number == NUM_STATES)) {

          state_fact[state_count].name = temp_arr[0];
          state_fact[state_count].population = atoi(temp_arr[1].c_str());
          state_fact[state_count].counties = (atoi(temp_arr[2].c_str()));
          state_fact[state_count].c =
              new county[state_fact[state_count].counties];
          state_count++;
          number++;
          county_count = 0;

        } else if (word_count > 3) { // use for loop

          state_fact[state_count - 1].c[county_count].name = temp_arr[0];
          state_fact[state_count - 1].c[county_count].population =
              atoi(temp_arr[1].c_str());
          state_fact[state_count - 1].c[county_count].avg_income =
              (float)atof(temp_arr[2].c_str());
          state_fact[state_count - 1].c[county_count].avg_house =
              (float)atof(temp_arr[3].c_str());
          state_fact[state_count - 1].c[county_count].cities =
              atoi(temp_arr[4].c_str());
          state_fact[state_count - 1].c[county_count].city_name =
              new string[state_fact[state_count - 1].c[county_count].cities];
          for (int i = 0;
               i < state_fact[state_count - 1].c[county_count].cities; i++)
            state_fact[state_count - 1].c[county_count].city_name[i] =
                temp_arr[5 + i];

          county_count++;
        } else if (number == NUM_STATES)
          break;

        tar_file.close();
      }
      for (int i = 0; i < NUM_STATES; i++) {
        cout << "State: " << state_fact[i].name << endl << "County: ";
        for (int j = 0; j < state_fact[i].counties; j++)
          cout << state_fact[i].c[j].name << " ";
        cout << endl;
      }

      cout << "\n\nSort State(A-Z): \n";
      sort_a_to_z(state_fact, NUM_STATES);

      cout << "\n\nSort State population: \n";
      sort_lar_pop_state(state_fact, NUM_STATES);

      cout << "\n\nThe county with largest population is: ";
      for (int i = 0; i < NUM_STATES - 1; i++)
        sort_county_largest_pop(state_fact[i].c, state_fact[i].counties);

      cout << "\n\nThe state with largest population is: \n";
      sort_state_largest_pop(state_fact, NUM_STATES);

      cout << "\n\nThe counties sorted(A-Z):\n ";
      for (int i = 0; i < NUM_STATES - 1; i++)
        sort_counties_a_to_z(state_fact[i].c, state_fact[i].counties);

      cout << "\n\nThe counties sorted by population:\n ";
      for (int i = 0; i < NUM_STATES - 1; i++)
        sort_counties_pop(state_fact[i].c, state_fact[i].counties);

      for (int i = 0; i < NUM_STATES - 1; i++)
        fit_county(state_fact, NUM_STATES);

      delete_info(state_fact, NUM_STATES);
    }

    cout << endl;
  
}
while (is_valid_arguments(argv) == true)
  ;

//            for (int k=0;k<word_count;k++){
//                cout<<"word #"<<k<<" : "<<temp_arr[k]<<endl;
//    cout<<"Do you want to input something again?"<<endl;
//    cout << "Please tell me the state and file name: \neg: 2
//    file.txt\n";
//    cin >> states >> argv[4];

return 0;
}

void sort_a_to_z(state *s1, int n) {
  int *index;
  index = new int[n];
  for (int i = 0; i < n; i++)
    index[i] = i;
  for (int i = 0; i < n - 1; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[index[i]].name > s1[index[j]].name) {
        temp = index[i];
        index[i] = index[j];
        index[j] = temp;
      }
    }
  for (int i = 0; i < n; i++)
    cout << s1[index[i]].name << endl;
  delete[] index;
}

void sort_lar_pop_state(state *s1, int n) {
  int *buffer;
  buffer = new int[n];
  for (int i = 0; i < n; i++)
    buffer[i] = i;
  for (int i = 0; i < n - 1; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[buffer[i]].population > s1[buffer[j]].population) {
        temp = buffer[i];
        buffer[i] = buffer[j];
        buffer[j] = temp;
      }
    }
  for (int i = 0; i < n; i++) {
    cout << s1[buffer[i]].name << ": ";
    cout << s1[buffer[i]].population << endl;
  }
  delete[] buffer;
}

void sort_county_largest_pop(county *s1, int n) {
  int *buffer;
  buffer = new int[n];
  for (int i = 0; i < n; i++)
    buffer[i] = i;
  for (int i = 0; i < n; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[buffer[i]].population < s1[buffer[j]].population) {
        temp = buffer[i];
        buffer[i] = buffer[j];
        buffer[j] = temp;
      }
    }
  for (int i = 0; i < n - n + 1; i++) {
    cout << s1[buffer[i]].name << " :";
    cout << s1[buffer[i]].population << endl;
  }
  delete[] buffer;
}

void sort_state_largest_pop(state *s1, int n) {
  int *buffer;
  buffer = new int[n];
  for (int i = 0; i < n; i++)
    buffer[i] = i;
  for (int i = 0; i < n; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[buffer[i]].population < s1[buffer[j]].population) {
        temp = buffer[i];
        buffer[i] = buffer[j];
        buffer[j] = temp;
      }
    }
  for (int i = 0; i < n - n + 1; i++) {
    cout << s1[buffer[i]].name << " :";
    cout << s1[buffer[i]].population << endl;
  }
  delete[] buffer;
}

void sort_counties_a_to_z(county *s1, int n) {
  int *index;
  index = new int[n];
  for (int i = 0; i < n; i++)
    index[i] = i;
  for (int i = 0; i < n - 1; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[index[i]].name > s1[index[j]].name) {
        temp = index[i];
        index[i] = index[j];
        index[j] = temp;
      }
    }
  for (int i = 0; i < n; i++)
    cout << s1[index[i]].name << endl;
  delete[] index;
}

void sort_counties_pop(county *s1, int n) {
  int *index;
  index = new int[n];
  for (int i = 0; i < n; i++)
    index[i] = i;
  for (int i = 0; i < n - 1; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[index[i]].population < s1[index[j]].population) {
        temp = index[i];
        index[i] = index[j];
        index[j] = temp;
      }
    }
  for (int i = 0; i < n; i++)
    cout << s1[index[i]].population << endl;
  delete[] index;
}

void sort_lar_county_pop(county *s1, int n) {
  int *buffer;
  buffer = new int[n];
  for (int i = 0; i < n; i++)
    buffer[i] = i;
  for (int i = 0; i < n; i++)
    for (int j = i + 1; j < n; j++) {
      int temp;
      if (s1[buffer[i]].population < s1[buffer[j]].population) {
        temp = buffer[i];
        buffer[i] = buffer[j];
        buffer[j] = temp;
      }
    }
  for (int i = 0; i < n - n + 1; i++) {
    cout << s1[buffer[i]].name << " :";
    cout << s1[buffer[i]].population << endl;
  }
  delete[] buffer;
}

void fit_county(state *s1, int n) {
  double money;
  cout << "Input a money amout: ";
  cin >> money;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < s1[i].counties; j++) {
      if (s1[i].c[j].avg_house >= money) {
        cout << s1[i].c[j].name << " :";
        cout << s1[i].c[j].avg_house << endl;
      }
    }
  }
}

void get_county_data(state *s, int state_count, int county_count,
                     string *temp_arr) {
  s[state_count - 1].c[county_count].name = temp_arr[0];
  s[state_count - 1].c[county_count].population = atoi(temp_arr[1].c_str());
  s[state_count - 1].c[county_count].avg_income =
      (float)atof(temp_arr[2].c_str());
  s[state_count - 1].c[county_count].avg_house =
      (float)atof(temp_arr[3].c_str());
  s[state_count - 1].c[county_count].cities = atoi(temp_arr[4].c_str());
  s[state_count - 1].c[county_count].city_name =
      new string[s[state_count - 1].c[county_count].cities];
  for (int i = 0; i < s[state_count - 1].c[county_count].cities; i++)
    s[state_count - 1].c[county_count].city_name[i] = temp_arr[5 + i];
}

county *create_counties(state *s, int state_count) {
  s[state_count].c = new county[s[state_count].counties];
  return s[state_count].c;
}

void get_state_data(state *s, int state_count, int county_count,
                    string *temp_arr) {
  s[state_count].name = temp_arr[0];
  s[state_count].population = atoi(temp_arr[1].c_str());
  s[state_count].counties = (atoi(temp_arr[2].c_str()));
  s[state_count].c = create_counties(s, state_count);
}

void delete_info(state *s, int n) {
  for (int i = 0; i < n; i++)
    for (int j = 0; j < s[i].counties; j++)
      delete[] s[i].c[j].city_name;
  for (int i = 0; i < n; i++)
    delete[] s[i].c;
  delete[] s;
}

state *create_states(int n) {
  state *s;
  s = new state[n];
  return s;
}
bool is_valid_arguments(char *info[]) {
  int x;
  cout << "Do you want to see other number? 1-YES, 0-no." << endl;
  cin >> x;
  if (x == 1) {
    int stats;
    char str[1024];
    cout << "states?" << endl;
    cin >> stats;
    cout << "file?" << endl;
    cin >> str;
    sprintf(info[2], "%d", stats);
    sprintf(info[4], "%s", str);

    return true;
  } else {
    return false;
  }
}

/*for(int k=0;k<state_count;k++){
        cout<<"State#"<<k+1<<": "<<state_fact[k].name<<endl;
        for(int g=0;g<county_count;g++)
                cout<<"counties#"<<k+1<<": "<<state_fact[k].c[g].name<<endl;
}
*/