To run this program, type "make", then type"./main".


