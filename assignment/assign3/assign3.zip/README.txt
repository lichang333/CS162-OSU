To run the test program, type "make", then type"./test".
